# Process Automation

## Programming the robotic arm
- Manual control
- Automatic control
- SCADA, OPC-UA

![RoboticArmPicture](./RoboticArm.png)
