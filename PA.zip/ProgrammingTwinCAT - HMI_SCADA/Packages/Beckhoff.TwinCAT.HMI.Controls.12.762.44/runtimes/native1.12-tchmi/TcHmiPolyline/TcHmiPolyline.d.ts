declare module TcHmi.Controls.Beckhoff {
    class TcHmiPolyline extends TcHmi.Controls.Beckhoff.TcHmiPolygon {
        #private;
    }
}
//# sourceMappingURL=TcHmiPolyline.d.ts.map